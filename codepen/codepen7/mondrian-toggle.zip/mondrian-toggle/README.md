# Mondrian toggle

A Pen created on CodePen.

Original URL: [https://codepen.io/alvaromontoro/pen/qEBqvwK](https://codepen.io/alvaromontoro/pen/qEBqvwK).

